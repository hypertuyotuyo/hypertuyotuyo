#!/usr/bin/env node
// ぺたぬり3D の MCP サーバー（依存なし。Node 20 以上の標準モジュールだけで動く。配布物にはこの 1 ファイルを入れる）
//
//   MCP クライアント ⇔（stdio：JSON-RPC 2.0、1 行 1 メッセージ）⇔ このサーバー ⇔（WebSocket）⇔ ぺたぬり3D
//
// ぺたぬり3D は WebView の中で動くので待ち受けできない。そこでこのサーバーが 127.0.0.1 の 47321〜47330 のうち
// 最初に空いているポートで WebSocket を待ち受け、アプリ（src/plugins/mcpBridge.js）が数秒おきにつなぎに来る。
// ツールの定義はアプリ側の登録（app.mcp.register）が正本。つながったときにアプリから一覧をもらって tools/list に出す
// （ここにツールの定義は書かない。前につないだアプリの一覧はキャッシュに残し、アプリが居ない間も一覧だけは出せるようにする）。
//
// アプリとの約束（WebSocket のテキストフレームに JSON を 1 つ）：
//   サーバー → アプリ  {type:'hello', server:'petanuri3d-mcp', version, protocol, port, pid, path}
//   アプリ → サーバー  {type:'hello', app:'petanuri3d', version, instanceId, mode, title,
//                       commands:[{name, title?, description, params(JSON Schema), timeout?(ms), annotations?}]}
//   アプリ → サーバー  {type:'commands', commands:[...]}（あとから登録が増えたとき）／{type:'info', title}（モデルを開いたとき）
//   サーバー → アプリ  {id, method, params} → アプリ {id, result} か {id, error:{message}}
//   結果に image:{data(base64), mimeType} / images:[...] があれば MCP の image コンテンツにし、残りは JSON のテキストにする
//
// 複数のアプリがつながったら、最後につないだものに送る。list_instances で一覧、各ツールの任意の引数 instance で送り先を選べる。
// 安全のため 127.0.0.1 だけで待ち受け、Origin が http(s)://localhost[:ポート] か http://127.0.0.1[:ポート] でない接続は拒否する
// （ほかのウェブサイトのページからつながれないように）。ログは stderr へ（stdout は MCP のメッセージ専用）。
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';

const VERSION = '1.0.2';
const PROTOCOL = 1;                          // アプリとの約束の版
const LATEST_MCP = '2025-06-18';             // クライアントが版を言わなかったときに返す版
const SERVER_PATH = fileURLToPath(import.meta.url).split(path.sep).join('/');
const DEFAULT_TIMEOUT_MS = 60_000;           // コマンドの返事を待つ時間（アプリがコマンドごとに長くできる）
const MAX_TIMEOUT_MS = 30 * 60_000;
const HELLO_TIMEOUT_MS = 10_000;             // つないでから hello が来るまで
const PING_INTERVAL_MS = 20_000;
const PONG_TIMEOUT_MS = 70_000;              // これだけ何も来なければ切れたとみなす
const MAX_MESSAGE_BYTES = 256 * 1024 * 1024; // 1 メッセージの上限（大きいテクスチャの PNG も通る大きさ）
const MAX_CONNECTIONS = 16;
const NO_APP_WAIT_MS = 3_000;                // hello の途中の接続があれば、ツールの呼び出しをこれだけ待つ
const [PORT_FIRST, PORT_LAST] = parsePorts(process.env.PETANURI3D_MCP_PORTS) ?? [47321, 47330];

// AI が読んで、そのままユーザーに頼めるように書く（アプリの AI 連携は既定で OFF。src/plugins/mcpBridge.js）。
// 入り切りの場所は ファイル → 環境設定 → AI 連携（2026-10-02 窓「MCP サーバー設定」から移した）
const NO_APP_MESSAGE = 'ぺたぬり3D を起動して、MCP 連携を ON にしてください（ファイル → 環境設定 → AI 連携 の「AI 連携（MCP）を使う」）。\n'
  + 'ぺたぬり3D につながっていません。ぺたぬり3D の AI 連携（MCP）は、はじめは OFF になっています。'
  + 'ユーザーに次のように頼んでください：\n'
  + '「ぺたぬり3D を起動して、上のメニューの ファイル →『環境設定』を開き、左の『AI 連携』で『AI 連携（MCP）を使う』にチェックを入れてください。'
  + '画面の下に『AI 連携：MCP サーバーにつながりました』と出れば準備完了です」\n'
  + 'ON にすると数秒でつながります（ON のまま起動していた場合は、最大 30 秒ほどかかることがあります）。'
  + 'つながったかは list_instances で確かめられます。つながったら、もう一度やり直してください';
const NO_PORT_MESSAGE = `ポート ${PORT_FIRST}〜${PORT_LAST} が全部ふさがっていて、ぺたぬり3D を待ち受けられません。`
  + '使っていない MCP クライアント（このサーバー）を閉じてからやり直してください';
const INSTANCE_DESC = '送り先のぺたぬり3D（list_instances の instance。先頭の数文字でもよい）。省くと最後につないだもの';
const INSTRUCTIONS = [
  'ぺたぬり3D（FBX に直接描いて UV テクスチャを作る、アニメ塗り向けの 3D ペイント）を操作します。',
  'アプリで MCP 連携が ON なら自動でつながります（list_instances で確かめられる）。',
  'アプリの AI 連携（MCP）は、はじめは OFF です。つながっていない（ツールが list_instances だけ・list_instances の instances が空・',
  'ツールが「ぺたぬり3D を起動して…」のエラーを返す）ときは、ユーザーに「ぺたぬり3D のメニューの ファイル →『環境設定』→『AI 連携』で『AI 連携（MCP）を使う』を ON にしてください」と頼んでください。',
  'ON になると数秒でつながり、ツールの一覧が増えます（notifications/tools/list_changed）。',
  '画面の座標 x, y は 3D ビューの CSS px（左上が原点）。screenshot の画像は scale 倍なので、画像の px ÷ scale が座標。',
  '流れの例：get_state → screenshot → select_tool・set_color・set_brush → stroke → screenshot で確認 → export_png。',
  '塗れたかは read_pixel（UV）でも確かめられる。undo で 1 手戻せる。',
].join('\n');
const LIST_INSTANCES_TOOL = {
  name: 'list_instances',
  description: 'つながっているぺたぬり3D の一覧（instance・開いているモデル・どれに送るか）。ほかのツールは引数 instance で送り先を選べる（省くと最後につないだもの）。'
    + 'instances が空なら、アプリの AI 連携（MCP）が OFF か、アプリが起動していない。message の手順をユーザーに頼む（ファイル → 環境設定 → AI 連携 の「AI 連携（MCP）を使う」を ON）',
  inputSchema: { type: 'object', properties: {} },
  annotations: { readOnlyHint: true },
};
const HELP = `ぺたぬり3D の MCP サーバー v${VERSION}
  MCP クライアントに stdio のサーバーとして登録して使う（コマンド node、引数にこのファイルのパス）。
    例：node "${SERVER_PATH}"
  ぺたぬり3D はファイル → 環境設定 → AI 連携 の「AI 連携（MCP）を使う」が ON のとき（はじめは OFF）、127.0.0.1:${PORT_FIRST}〜${PORT_LAST} で待ち受けるこのサーバーへ自動でつなぎに来る。
  環境変数：PETANURI3D_MCP_PORTS=47321-47330（待ち受けるポートの範囲）
            PETANURI3D_MCP_CACHE=<ファイル> | off（アプリのツール一覧のキャッシュ。既定はユーザーのキャッシュのフォルダ）
`;

function parsePorts(s) {
  const m = /^\s*(\d{1,5})(?:\s*-\s*(\d{1,5}))?\s*$/.exec(s ?? '');
  if (!m) return null;
  const a = +m[1], b = +(m[2] ?? m[1]);
  return a > 0 && b >= a && b < 65536 ? [a, b] : null;
}
function log(...a) {
  try { process.stderr.write(`[petanuri3d-mcp] ${a.map((x) => (typeof x === 'string' ? x : x?.stack ?? String(x))).join(' ')}\n`); } catch { /* 何もしない */ }
}

class ToolError extends Error {}
const rpcError = (code, message) => Object.assign(new Error(message), { code });

// ---------------------------------------------------------------------------
// WebSocket（RFC 6455）：サーバー側だけを手書き
// ---------------------------------------------------------------------------
const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const UTF8 = new TextDecoder('utf-8', { fatal: true });
const ORIGIN_OK = [/^https?:\/\/localhost(:\d{1,5})?$/, /^http:\/\/127\.0\.0\.1(:\d{1,5})?$/];
const HOST_OK = /^(127\.0\.0\.1|localhost|\[::1\])(:\d{1,5})?$/i;

/** ほかのウェブサイトのページからつながれないように、自分の PC のページ（アプリ・開発用のサーバー）だけを通す */
function isAllowedOrigin(origin) {
  return typeof origin === 'string' && ORIGIN_OK.some((re) => re.test(origin));
}
function validCloseCode(c) {
  return (c >= 1000 && c <= 1014 && c !== 1004 && c !== 1005 && c !== 1006) || (c >= 3000 && c <= 4999);
}

class WsConnection {
  /** @param {import('node:net').Socket} socket  受信は feed(head) を呼んでから（onmessage を付ける前に解釈しないように） */
  constructor(socket) {
    this.socket = socket;
    this.chunks = [];          // 受け取ったがまだ解釈していないバイト
    this.buffered = 0;
    this.fragments = null;     // 分割されたメッセージの途中 { opcode, parts, size }
    this.closeSent = false;
    this.stopped = false;      // 受信の解釈をやめた（close を受けた・約束違反）
    this.ended = false;        // ソケットが閉じた
    this.lastSeen = Date.now();
    this.onmessage = null;
    this.onclose = null;
    socket.setNoDelay(true);
    socket.on('error', () => {}); // close が続けて来る
    socket.on('close', () => this._ended());
  }
  /** 受信を始める。head は upgrade と一緒に届いた続きのバイト */
  feed(head) {
    this.socket.on('data', (d) => this._onData(d));
    if (head && head.length) this._onData(head);
  }

  _onData(d) {
    if (this.stopped) return;
    this.lastSeen = Date.now();
    this.chunks.push(d);
    this.buffered += d.length;
    try { this._parse(); } catch (e) { log('受信の解釈で例外', e); this.fail(1011, 'internal error'); }
  }
  /** 先頭の n バイトを見る（取り出さない。n はヘッダーの長さ以下） */
  _peek(n) {
    const c0 = this.chunks[0];
    return c0.length >= n ? c0.subarray(0, n) : Buffer.concat(this.chunks, n);
  }
  /** 先頭の n バイトを取り出す */
  _take(n) {
    this.buffered -= n;
    const c0 = this.chunks[0];
    if (n === c0.length) return this.chunks.shift();
    if (n < c0.length) { this.chunks[0] = c0.subarray(n); return c0.subarray(0, n); }
    const out = Buffer.allocUnsafe(n);
    let off = 0;
    while (off < n) {
      const c = this.chunks[0];
      const k = Math.min(c.length, n - off);
      c.copy(out, off, 0, k);
      off += k;
      if (k === c.length) this.chunks.shift(); else this.chunks[0] = c.subarray(k);
    }
    return out;
  }

  _parse() {
    while (!this.stopped && this.buffered >= 2) {
      const h = this._peek(Math.min(this.buffered, 14));
      const fin = (h[0] & 0x80) !== 0;
      const rsv = h[0] & 0x70;
      const opcode = h[0] & 0x0f;
      const masked = (h[1] & 0x80) !== 0;
      let len = h[1] & 0x7f;
      let off = 2;
      if (rsv) { this.fail(1002, 'protocol error'); log('RSV ビットが立っている（拡張は使わない）'); return; }
      if (!masked) { this.fail(1002, 'protocol error'); log('クライアントのフレームにマスクが無い'); return; }
      if (len === 126) {
        if (h.length < 4) return;
        len = h.readUInt16BE(2);
        off = 4;
      } else if (len === 127) {
        if (h.length < 10) return;
        const hi = h.readUInt32BE(2);
        if (hi > 0x1fffff) { this.fail(1009, 'too big'); return; }
        len = hi * 0x100000000 + h.readUInt32BE(6);
        off = 10;
      }
      if (h.length < off + 4) return;
      if (opcode >= 0x8) {
        if (!fin || len > 125) { this.fail(1002, 'protocol error'); log('制御フレームが不正'); return; }
      } else if (len + (this.fragments ? this.fragments.size : 0) > MAX_MESSAGE_BYTES) {
        this.fail(1009, 'too big'); log(`メッセージが大きすぎる（${len} バイト）`); return;
      }
      if (this.buffered < off + 4 + len) return; // 本体がまだ届いていない
      const mask = Buffer.from(h.subarray(off, off + 4));
      this._take(off + 4);
      const payload = len ? this._take(len) : Buffer.alloc(0);
      for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      this._frame(fin, opcode, payload);
    }
  }

  _frame(fin, opcode, payload) {
    switch (opcode) {
      case 0x0: { // 続き
        const f = this.fragments;
        if (!f) { this.fail(1002, 'protocol error'); log('続きのフレームだけが来た'); return; }
        f.parts.push(payload);
        f.size += payload.length;
        if (fin) { this.fragments = null; this._message(f.opcode, Buffer.concat(f.parts, f.size)); }
        return;
      }
      case 0x1: case 0x2: // テキスト・バイナリ
        if (this.fragments) { this.fail(1002, 'protocol error'); log('分割の途中に新しいメッセージ'); return; }
        if (fin) this._message(opcode, payload);
        else this.fragments = { opcode, parts: [payload], size: payload.length };
        return;
      case 0x8: { // close：同じ番号を返して閉じる
        if (payload.length === 1) { this.fail(1002, 'protocol error'); return; }
        let code = 1000;
        if (payload.length >= 2) { const c = payload.readUInt16BE(0); code = validCloseCode(c) ? c : 1002; }
        this.stopped = true;
        this._sendClose(code);
        this.socket.end();
        setTimeout(() => this.socket.destroy(), 1000).unref();
        return;
      }
      case 0x9: this._send(0xA, payload); return; // ping → pong
      case 0xA: return;                            // pong（lastSeen は _onData で更新済み）
      default: this.fail(1002, 'protocol error'); log(`知らない opcode ${opcode}`);
    }
  }

  _message(opcode, data) {
    if (opcode !== 0x1) return; // バイナリは使わない
    let text;
    try { text = UTF8.decode(data); } catch { this.fail(1007, 'invalid utf-8'); return; }
    try { this.onmessage?.(text); } catch (e) { log('メッセージの処理で例外', e); }
  }

  _send(opcode, payload) {
    const s = this.socket;
    if (this.ended || s.destroyed || !s.writable) return false;
    const len = payload.length;
    let head;
    if (len < 126) {
      head = Buffer.from([0x80 | opcode, len]);
    } else if (len < 0x10000) {
      head = Buffer.allocUnsafe(4); head[0] = 0x80 | opcode; head[1] = 126; head.writeUInt16BE(len, 2);
    } else {
      head = Buffer.allocUnsafe(10); head[0] = 0x80 | opcode; head[1] = 127;
      head.writeUInt32BE(Math.floor(len / 0x100000000), 2); head.writeUInt32BE(len >>> 0, 6);
    }
    s.cork();
    s.write(head);
    if (len) s.write(payload);
    s.uncork();
    return true;
  }
  /** テキストを 1 メッセージ送る（サーバーからのフレームはマスクしない） */
  send(text) { return this.closeSent ? false : this._send(0x1, Buffer.from(text, 'utf8')); }
  ping() { if (!this.closeSent) this._send(0x9, Buffer.alloc(0)); }
  _sendClose(code, reason = '') {
    if (this.closeSent) return;
    this.closeSent = true;
    const r = Buffer.from(String(reason).replace(/[^\x20-\x7e]/g, ''), 'ascii').subarray(0, 123);
    const p = Buffer.allocUnsafe(2 + r.length);
    p.writeUInt16BE(code, 0);
    r.copy(p, 2);
    this._send(0x8, p);
  }
  /** 閉じる（相手の close を待ち、来なければ 2 秒で切る） */
  close(code = 1000, reason = '') {
    this._sendClose(code, reason);
    setTimeout(() => this.socket.destroy(), 2000).unref();
  }
  /** 約束違反：close を送って受信をやめる */
  fail(code, reason) {
    if (this.stopped) return;
    this.stopped = true;
    this.chunks = [];
    this.buffered = 0;
    this._sendClose(code, reason);
    this.socket.end();
    setTimeout(() => this.socket.destroy(), 1000).unref();
  }
  _ended() {
    if (this.ended) return;
    this.ended = true;
    this.stopped = true;
    try { this.onclose?.(); } catch (e) { log(e); }
  }
}

function rejectUpgrade(socket, status, text, extra = []) {
  const body = `${text}\n`;
  try {
    socket.end([
      `HTTP/1.1 ${status} ${http.STATUS_CODES[status] ?? ''}`, 'Connection: close', 'Content-Type: text/plain; charset=utf-8',
      `Content-Length: ${Buffer.byteLength(body)}`, ...extra, '', body,
    ].join('\r\n'));
  } catch { socket.destroy(); }
}

// ---------------------------------------------------------------------------
// アプリとの接続（hello・コマンド一覧・要求と応答）
// ---------------------------------------------------------------------------
function sanitizeCommands(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  const seen = new Set();
  for (const c of list) {
    if (!c || typeof c.name !== 'string' || !/^[a-z][a-z0-9_]{0,63}$/.test(c.name)) continue;
    if (c.name === LIST_INSTANCES_TOOL.name || seen.has(c.name)) continue;
    seen.add(c.name);
    const params = c.params && typeof c.params === 'object' && !Array.isArray(c.params) ? c.params : { type: 'object', properties: {} };
    out.push({
      name: c.name,
      title: typeof c.title === 'string' ? c.title : undefined,
      description: typeof c.description === 'string' ? c.description : '',
      params,
      timeout: Number.isFinite(c.timeout) ? Math.min(MAX_TIMEOUT_MS, Math.max(1000, c.timeout)) : DEFAULT_TIMEOUT_MS,
      annotations: c.annotations && typeof c.annotations === 'object' && !Array.isArray(c.annotations) ? c.annotations : undefined,
    });
  }
  return out;
}

/** アプリのコマンド → MCP のツール（引数 instance を足す） */
function toTool(c) {
  const schema = JSON.parse(JSON.stringify(c.params));
  schema.type = 'object';
  if (!schema.properties || typeof schema.properties !== 'object' || Array.isArray(schema.properties)) schema.properties = {};
  schema.properties.instance = { type: 'string', description: INSTANCE_DESC };
  const t = { name: c.name, description: c.description, inputSchema: schema };
  if (c.title) t.title = c.title;
  if (c.annotations) t.annotations = c.annotations;
  return t;
}

function cachePath() {
  const env = process.env.PETANURI3D_MCP_CACHE;
  if (env === 'off' || env === '0') return null;
  if (env) return env;
  const base = process.platform === 'win32'
    ? (process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'))
    : (process.env.XDG_CACHE_HOME || path.join(os.homedir(), '.cache'));
  return path.join(base, 'PetaNuri3D', 'mcp-tools.json');
}

class Bridge {
  constructor() {
    this.handshaking = new Set(); // hello 前の接続
    this.apps = [];               // hello 済み。最後が「いま使う」もの
    this.seq = 1;
    this.port = null;
    this.onToolsChanged = () => {};
    this._waiters = new Set();
    this.cached = [];
    this._cacheText = null;
    const f = cachePath();
    if (f) {
      try {
        this.cached = sanitizeCommands(JSON.parse(fs.readFileSync(f, 'utf8')).commands);
        this._cacheText = JSON.stringify(this.cached);
      } catch { /* まだ無い */ }
    }
  }
  get size() { return this.handshaking.size + this.apps.length; }
  get active() { return this.apps.at(-1) ?? null; }

  accept(ws, info) {
    const conn = { ws, info, instanceId: null, commands: [], pending: new Map(), connectedAt: null, version: '', mode: '', title: null };
    this.handshaking.add(conn);
    ws.onmessage = (text) => this._onMessage(conn, text);
    ws.onclose = () => this._onClose(conn);
    ws.send(JSON.stringify({ type: 'hello', server: 'petanuri3d-mcp', version: VERSION, protocol: PROTOCOL, port: this.port, pid: process.pid, path: SERVER_PATH }));
    conn.helloTimer = setTimeout(() => {
      if (conn.instanceId) return;
      log(`hello が来ないので切ります（${info.origin}）`);
      ws.close(1008, 'hello timeout');
    }, HELLO_TIMEOUT_MS);
  }

  _onMessage(conn, text) {
    let msg;
    try { msg = JSON.parse(text); } catch { log('JSON でないメッセージを捨てました'); return; }
    if (!msg || typeof msg !== 'object') return;
    if (msg.type === 'hello') { this._onHello(conn, msg); return; }
    if (!conn.instanceId) return; // hello の前は何も受けない
    if (msg.type === 'commands') {
      conn.commands = sanitizeCommands(msg.commands);
      this._saveCache(conn);
      this.onToolsChanged();
      return;
    }
    if (msg.type === 'info') {
      if (typeof msg.title === 'string' || msg.title === null) conn.title = msg.title;
      return;
    }
    if (msg.id != null) {
      const p = conn.pending.get(msg.id);
      if (!p) return; // 打ち切った後の返事
      conn.pending.delete(msg.id);
      clearTimeout(p.timer);
      if (msg.error) p.reject(new ToolError(String(msg.error?.message ?? msg.error)));
      else p.resolve(msg.result);
    }
  }

  _onHello(conn, msg) {
    if (conn.instanceId) return;
    if (msg.app !== 'petanuri3d' || typeof msg.instanceId !== 'string' || !msg.instanceId) {
      log('ぺたぬり3D ではない相手なので切ります');
      conn.ws.close(1008, 'bad hello');
      return;
    }
    clearTimeout(conn.helloTimer);
    conn.instanceId = msg.instanceId.slice(0, 64);
    conn.version = String(msg.version ?? '');
    conn.mode = String(msg.mode ?? '');
    conn.title = typeof msg.title === 'string' ? msg.title : null;
    conn.commands = sanitizeCommands(msg.commands);
    conn.connectedAt = new Date();
    this.handshaking.delete(conn);
    // 同じアプリの古い接続が残っていたら外す（つなぎ直し）
    for (const old of this.apps.filter((a) => a.instanceId === conn.instanceId)) {
      this._drop(old, 'ぺたぬり3D がつなぎ直しました');
      old.ws.close(1000);
    }
    this.apps.push(conn);
    log(`ぺたぬり3D がつながりました（instance ${conn.instanceId}・コマンド ${conn.commands.length}・${conn.info.origin}）`);
    this._saveCache(conn);
    for (const w of [...this._waiters]) w();
    this.onToolsChanged();
  }

  _onClose(conn) {
    clearTimeout(conn.helloTimer);
    this.handshaking.delete(conn);
    if (!this.apps.includes(conn)) return;
    this._drop(conn, 'ぺたぬり3D との接続が切れました');
    log(`ぺたぬり3D が切れました（instance ${conn.instanceId}）`);
    this.onToolsChanged();
  }

  _drop(conn, reason) {
    this.apps = this.apps.filter((a) => a !== conn);
    for (const p of conn.pending.values()) { clearTimeout(p.timer); p.reject(new ToolError(reason)); }
    conn.pending.clear();
  }

  /** アプリにコマンドを送って返事を待つ */
  request(conn, method, params, timeoutMs) {
    return new Promise((resolve, reject) => {
      const id = this.seq++;
      const timer = setTimeout(() => {
        conn.pending.delete(id);
        reject(new ToolError(`ぺたぬり3D から ${method} の返事がありません（${Math.round(timeoutMs / 1000)} 秒で打ち切りました）`));
      }, timeoutMs);
      conn.pending.set(id, { resolve, reject, timer });
      if (!conn.ws.send(JSON.stringify({ id, method, params }))) {
        clearTimeout(timer);
        conn.pending.delete(id);
        reject(new ToolError('ぺたぬり3D との接続が切れています'));
      }
    });
  }

  /** hello の途中の接続があれば少し待つ（起動直後・ON にした直後の取りこぼしを減らす）→ アプリが居るか */
  waitForApp(ms) {
    if (this.apps.length || !this.handshaking.size) return Promise.resolve(this.apps.length > 0);
    return new Promise((resolve) => {
      const done = () => { clearTimeout(t); this._waiters.delete(done); resolve(this.apps.length > 0); };
      const t = setTimeout(done, ms);
      this._waiters.add(done);
    });
  }

  /** instance（全部か、先頭の数文字）→ 接続 */
  find(instance) {
    const s = String(instance);
    const exact = this.apps.find((a) => a.instanceId === s);
    if (exact) return exact;
    const hits = this.apps.filter((a) => a.instanceId.startsWith(s));
    return hits.length === 1 ? hits[0] : null;
  }

  /** tools/list に出すコマンド（つながっている全部の和。同じ名前は新しい接続の定義。誰も居なければキャッシュ） */
  commandsForList() {
    const map = new Map();
    for (const a of this.apps.length ? this.apps : [{ commands: this.cached }]) for (const c of a.commands) map.set(c.name, c);
    return [...map.values()];
  }

  _saveCache(conn) {
    const f = cachePath();
    if (!f || !conn.commands.length) return;
    const text = JSON.stringify(conn.commands);
    if (text === this._cacheText) return;
    this._cacheText = text;
    this.cached = conn.commands;
    const tmp = `${f}.${process.pid}.tmp`;
    try {
      fs.mkdirSync(path.dirname(f), { recursive: true });
      fs.writeFileSync(tmp, JSON.stringify({ savedAt: new Date().toISOString(), appVersion: conn.version, commands: conn.commands }, null, 1));
      fs.renameSync(tmp, f); // 複数のサーバーが同時に書いても壊れないように
    } catch (e) {
      log(`ツール一覧のキャッシュを書けません：${e.message}`);
      try { fs.rmSync(tmp, { force: true }); } catch { /* 何もしない */ }
    }
  }

  describe() {
    const active = this.active;
    const out = {
      server: { version: VERSION, port: this.port, pid: process.pid, path: SERVER_PATH },
      instances: [...this.apps].reverse().map((a) => ({
        instance: a.instanceId, active: a === active, model: a.title, app_version: a.version, mode: a.mode,
        origin: a.info.origin, connected_at: a.connectedAt.toISOString(), commands: a.commands.length,
      })),
    };
    if (!this.apps.length) out.message = this.port ? NO_APP_MESSAGE : NO_PORT_MESSAGE;
    return out;
  }

  closeAll() { for (const c of [...this.handshaking, ...this.apps]) c.ws.close(1001, 'server exit'); }
}

// ---------------------------------------------------------------------------
// MCP（stdio の JSON-RPC 2.0）
// ---------------------------------------------------------------------------
// JSON は字下げしない（AI が読む量を減らす）
const textResult = (v) => ({ content: [{ type: 'text', text: typeof v === 'string' ? v : JSON.stringify(v) }] });
const errorResult = (message) => ({ content: [{ type: 'text', text: message }], isError: true });

/** アプリの結果 → MCP のコンテンツ（image / images は画像に、残りは JSON のテキストに） */
function toContent(result) {
  const images = [];
  let rest = result;
  if (result && typeof result === 'object' && !Array.isArray(result) && (result.image || result.images)) {
    const { image, images: list, ...others } = result;
    for (const im of [image, ...(Array.isArray(list) ? list : [])]) {
      if (im && typeof im.data === 'string') images.push({ type: 'image', data: im.data, mimeType: typeof im.mimeType === 'string' ? im.mimeType : 'image/png' });
    }
    rest = others;
  }
  const content = [];
  if (rest !== undefined) content.push({ type: 'text', text: typeof rest === 'string' ? rest : JSON.stringify(rest) });
  content.push(...images);
  if (!content.length) content.push({ type: 'text', text: 'OK' });
  return { content };
}

class McpServer {
  /** @param {Bridge} bridge  @param {Promise<void>} listening */
  constructor(bridge, listening) {
    this.bridge = bridge;
    this.listening = listening;
    this.initialized = false;
    this.inflight = new Set();
    this.cancelled = new Set();
    this.listedSig = null;   // クライアントが最後に受け取った一覧
    this.notified = false;
    bridge.onToolsChanged = () => this._toolsChanged();
  }

  write(msg) {
    try { process.stdout.write(`${JSON.stringify(msg)}\n`); } catch (e) { log('stdout に書けません', e); }
  }
  tools() { return [...this.bridge.commandsForList().map(toTool), LIST_INSTANCES_TOOL]; }

  /** ツールの顔ぶれが変わったら知らせる（クライアントが一度でも一覧を取っていれば。取り直すまでは 1 回だけ） */
  _toolsChanged() {
    if (!this.initialized || this.listedSig === null || this.notified) return;
    if (JSON.stringify(this.tools()) === this.listedSig) return;
    this.notified = true;
    this.write({ jsonrpc: '2.0', method: 'notifications/tools/list_changed' });
  }

  async onLine(line) {
    const s = line.trim();
    if (!s) return;
    let msg;
    try { msg = JSON.parse(s); } catch {
      this.write({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } });
      return;
    }
    if (Array.isArray(msg)) { // 一括（古い版の MCP）
      if (!msg.length) { this.write({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Invalid Request' } }); return; }
      const out = (await Promise.all(msg.map((m) => this.handle(m)))).filter(Boolean);
      if (out.length) this.write(out);
      return;
    }
    const r = await this.handle(msg);
    if (r) this.write(r);
  }

  async handle(msg) {
    if (!msg || typeof msg !== 'object' || Array.isArray(msg)) return { jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Invalid Request' } };
    if (typeof msg.method !== 'string') return null; // クライアントからの応答（こちらから要求は出さない）
    const hasId = Object.prototype.hasOwnProperty.call(msg, 'id') && msg.id !== null;
    if (!hasId) { this.notification(msg.method, msg.params); return null; }
    const { id } = msg;
    this.inflight.add(id);
    try {
      const result = await this.request(msg.method, msg.params && typeof msg.params === 'object' ? msg.params : {});
      return this.cancelled.delete(id) ? null : { jsonrpc: '2.0', id, result };
    } catch (e) {
      if (this.cancelled.delete(id)) return null;
      return { jsonrpc: '2.0', id, error: { code: Number.isInteger(e?.code) ? e.code : -32603, message: String(e?.message ?? e) } };
    } finally {
      this.inflight.delete(id);
    }
  }

  notification(method, params) {
    if (method === 'notifications/initialized') { this.initialized = true; return; }
    if (method === 'notifications/cancelled') {
      const id = params?.requestId;
      if (this.inflight.has(id)) this.cancelled.add(id); // 取り消された要求には返事をしない
    }
  }

  async request(method, params) {
    switch (method) {
      case 'initialize': {
        const v = typeof params.protocolVersion === 'string' && params.protocolVersion ? params.protocolVersion : LATEST_MCP;
        const ci = params.clientInfo;
        log(`MCP クライアント：${ci?.name ?? '?'} ${ci?.version ?? ''}（プロトコル ${v}）`);
        return {
          protocolVersion: v,
          capabilities: { tools: { listChanged: true } },
          serverInfo: { name: 'petanuri3d', title: 'ぺたぬり3D', version: VERSION },
          instructions: INSTRUCTIONS,
        };
      }
      case 'ping': return {};
      case 'tools/list': {
        const tools = this.tools();
        this.listedSig = JSON.stringify(tools);
        this.notified = false;
        return { tools };
      }
      case 'tools/call': return this.callTool(params);
      case 'resources/list': return { resources: [] };
      case 'resources/templates/list': return { resourceTemplates: [] };
      case 'prompts/list': return { prompts: [] };
      case 'logging/setLevel': return {};
      default: throw rpcError(-32601, `Method not found: ${method}`);
    }
  }

  async callTool(params) {
    const name = params?.name;
    if (typeof name !== 'string' || !name) throw rpcError(-32602, 'ツールの名前（name）がありません');
    const args = params.arguments && typeof params.arguments === 'object' && !Array.isArray(params.arguments) ? params.arguments : {};
    await this.listening;
    const b = this.bridge;
    if (name === LIST_INSTANCES_TOOL.name) return textResult(b.describe());
    if (!b.port) return errorResult(NO_PORT_MESSAGE);
    const { instance, ...rest } = args;
    if (!b.apps.length) await b.waitForApp(NO_APP_WAIT_MS);
    if (!b.apps.length) return errorResult(NO_APP_MESSAGE);
    let target = b.active;
    if (instance != null && instance !== '') {
      target = b.find(instance);
      if (!target) return errorResult(`instance「${instance}」のぺたぬり3D は見つかりません。list_instances で確かめてください`);
    }
    const cmd = target.commands.find((c) => c.name === name);
    if (!cmd) {
      if (!b.commandsForList().some((c) => c.name === name)) throw rpcError(-32602, `Unknown tool: ${name}`);
      return errorResult(`このぺたぬり3D（instance ${target.instanceId}）には ${name} がありません（版が違うかもしれません）`);
    }
    const t0 = Date.now();
    try {
      const result = await b.request(target, name, rest, cmd.timeout);
      log(`${name}：${Date.now() - t0}ms`);
      return toContent(result);
    } catch (e) {
      log(`${name}：失敗（${Date.now() - t0}ms）${e.message}`);
      if (e instanceof ToolError) return errorResult(e.message);
      throw e;
    }
  }
}

// ---------------------------------------------------------------------------
// 起動
// ---------------------------------------------------------------------------
const argv = process.argv.slice(2);
if (argv.includes('--version')) { process.stdout.write(`${VERSION}\n`); process.exit(0); }
if (argv.includes('--help') || argv.includes('-h')) { process.stdout.write(HELP); process.exit(0); }
if (+process.versions.node.split('.')[0] < 20) log(`node のバージョンが ${process.versions.node} です。20 以上で動かしてください`);

const bridge = new Bridge();
// 普通の HTTP には 426 だけ返す（アプリは居るかをこれで確かめてから WebSocket を開く。中身は何も出さない）
const httpServer = http.createServer((req, res) => {
  res.writeHead(426, { 'Content-Type': 'text/plain; charset=utf-8', Upgrade: 'websocket', Connection: 'close' });
  res.end('petanuri3d MCP bridge (WebSocket only)\n');
});
httpServer.on('upgrade', (req, socket, head) => {
  socket.on('error', () => {});
  const origin = req.headers.origin;
  if (!isAllowedOrigin(origin)) {
    log(`接続を断りました（Origin: ${origin ?? 'なし'}）`);
    rejectUpgrade(socket, 403, 'forbidden origin');
    return;
  }
  if (!HOST_OK.test(req.headers.host ?? '')) { log(`接続を断りました（Host: ${req.headers.host}）`); rejectUpgrade(socket, 403, 'forbidden host'); return; }
  if (req.method !== 'GET' || String(req.headers.upgrade ?? '').toLowerCase() !== 'websocket') { rejectUpgrade(socket, 400, 'websocket upgrade expected'); return; }
  if (req.headers['sec-websocket-version'] !== '13') { rejectUpgrade(socket, 426, 'unsupported websocket version', ['Sec-WebSocket-Version: 13']); return; }
  const key = req.headers['sec-websocket-key'];
  if (typeof key !== 'string' || !/^[A-Za-z0-9+/]{22}==$/.test(key)) { rejectUpgrade(socket, 400, 'bad Sec-WebSocket-Key'); return; }
  if (bridge.size >= MAX_CONNECTIONS) { rejectUpgrade(socket, 503, 'too many connections'); return; }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write(['HTTP/1.1 101 Switching Protocols', 'Upgrade: websocket', 'Connection: Upgrade', `Sec-WebSocket-Accept: ${accept}`, '', ''].join('\r\n'));
  const ws = new WsConnection(socket);
  bridge.accept(ws, { origin });
  ws.feed(head);
});
httpServer.on('clientError', (err, socket) => { try { socket.destroy(); } catch { /* 何もしない */ } });

function tryListen(port) {
  return new Promise((resolve, reject) => {
    const onError = (e) => { httpServer.off('listening', onOk); if (e.code === 'EADDRINUSE' || e.code === 'EACCES') resolve(false); else reject(e); };
    const onOk = () => { httpServer.off('error', onError); resolve(true); };
    httpServer.once('error', onError);
    httpServer.once('listening', onOk);
    httpServer.listen(port, '127.0.0.1');
  });
}
const listening = (async () => {
  for (let port = PORT_FIRST; port <= PORT_LAST; port++) {
    try {
      if (await tryListen(port)) { bridge.port = port; break; }
    } catch (e) { log(`ポート ${port} で待ち受けられません`, e); }
  }
  if (bridge.port) log(`ws://127.0.0.1:${bridge.port} で待ち受けています（v${VERSION}・pid ${process.pid}）`);
  else log(NO_PORT_MESSAGE);
})();

const mcp = new McpServer(bridge, listening);

// 何も来なくなった接続を切る（ブラウザは ping に自動で pong を返す）
setInterval(() => {
  const now = Date.now();
  for (const c of [...bridge.handshaking, ...bridge.apps]) {
    if (now - c.ws.lastSeen > PONG_TIMEOUT_MS) { log('返事が無いので切ります'); c.ws.socket.destroy(); continue; }
    c.ws.ping();
  }
}, PING_INTERVAL_MS).unref();

let shuttingDown = false;
function shutdown(why) {
  if (shuttingDown) return;
  shuttingDown = true;
  log(`終わります（${why}）`);
  bridge.closeAll();
  httpServer.close();
  setTimeout(() => process.exit(0), 300).unref();
}
const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
rl.on('line', (line) => { mcp.onLine(line).catch((e) => log('メッセージを処理できませんでした', e)); });
rl.on('close', () => shutdown('stdin が閉じました'));
process.stdout.on('error', (e) => shutdown(`stdout に書けません（${e.code}）`));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
